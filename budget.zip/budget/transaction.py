import common
import category

TRANSACTIONS = []
TRANSACTION_OPERATIONS = ["Add", "List"]


def transation_operations():
    print()
    for i, t in enumerate(TRANSACTION_OPERATIONS, start=1):
        print("{}. {}".format(i, t))

def add_transaction():
    print()
    try:
        amount = int(input("Amount: "))
        category.list_categories()
        category_id = int(input("Category: "))
        if common.check_menu_id(category_id, category.CATEGORIES):
            TRANSACTIONS.append({"category": category_id, "amount": amount})
        else:
            print("Please, write correct number")
    except ValueError:
        print("Amount is not correct")

def list_transactions():
    print()
    print("Transactions:")
    for t in TRANSACTIONS:
        category_name = category.CATEGORIES[t["category"] - 1]
        print("* {} - {}".format(category_name, t["amount"]))
    print("---------------------------\n")

def get_sum_by_category(category_id):
    result = 0
    for t in TRANSACTIONS:
        if t["category"] == category_id:
            result = result + t["amount"]
    return result

def transaction_handler():
    # Handler function of the transaction module
    transation_operations()
    operation_id = common.get_menu_id("Choose operation please")
    if common.check_menu_id(operation_id, TRANSACTION_OPERATIONS):
        if operation_id == 1:
            add_transaction()
        elif operation_id == 2:
            list_transactions()
