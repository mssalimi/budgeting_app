def get_menu_id(message):
    # Prompt to choose one of the options and fails if it is not an integer
    try:
        menu_id = int(input("{}: ".format(message)))
        return menu_id
    except ValueError:
        print("Menu id is not correct")

def check_menu_id(id, options):
    # Checks whether id belogs to options
    if id in range(1, len(options) + 1):
        return True
    else:
        print("Choose one the options given above")
