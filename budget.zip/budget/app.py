import common
import category
import transaction
import budgeting

SECTIONS = ["Transactions", "Categories", "Budgeting"]

    
def main_sections():
    print()
    # Prints main sections to operate
    for i, s in enumerate(SECTIONS, start=1):
        print("{}. {}".format(i, s))


def app():
    # The main app of the budgeting application
    main_sections()
    section_id = common.get_menu_id("Choose section to operate")
    if section_id == 1:
        transaction.transaction_handler()
    elif section_id == 2:
        category.category_handler()
    elif section_id == 3:
        budgeting.handler()
    return section_id


# To not to execute the code on import
if __name__ == "__main__":
    print("Budgeting application")
    print("======================\n")
    while True:
        print("Sections (input 0 to exit): ")
        s_id = app()
        if s_id == 0:
            # Quit if section id is zero
            print("Bye bye!")
            break