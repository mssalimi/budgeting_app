import common
import category
import transaction

BUDGETS = {}
BUDGET_OPERATIONS = ["Add", "List", "Change"]

def operations():
    print()
    for i, b in enumerate(BUDGET_OPERATIONS, start=1):
        print("{}. {}".format(i, b))

def add_budget():
    try:
        amount = int(input("Limit: "))
        category.list_categories()
        category_id = int(input("Category: "))

        if common.check_menu_id(category_id, category.CATEGORIES):
            BUDGETS[category_id] = amount

    except ValueError:
        print("Please, write correct number")

def list_budgets():
    print()
    print("Budget limits:")
    for key in BUDGETS:
        category_name = category.CATEGORIES[key - 1]
        spending = transaction.get_sum_by_category(key)
        exceed = spending - BUDGETS[key]
        if exceed < 0:
            print("* {} exceeds 0, limit is {} ".format(category_name, BUDGETS[key]))
        else:
            print("* {} exceeds {}, limit is {} ".format(category_name, exceed, BUDGETS[key]))
    print("---------------------------\n")

def change_limit():
    print()
    try:
        category.list_categories()
        category_id = int(input("Category: "))
        if category_id not in BUDGETS:
            print("Budget limit is not set")
        else:
            amount = int(input("Limit: "))
            BUDGETS[category_id] = amount
    except ValueError:
        print("Please write correct number")


def handler():
    operations()
    op_id = common.get_menu_id("Choose operation please")
    if common.check_menu_id(op_id, BUDGET_OPERATIONS):
        if op_id == 1:
            add_budget()
        elif op_id == 2:
            list_budgets()
        elif op_id == 3:
            change_limit()
