import common

CATEGORIES = []
CATEGORY_OPERATIONS = ["Add", "List"]

def category_operations():
    print()
    for i, c in enumerate(CATEGORY_OPERATIONS, start=1):
        print("{}. {}".format(i, c))

def add_category():
    print()
    name = input("New category: ")
    CATEGORIES.append(name)

def list_categories():
    print()
    print("Categories:")
    for i, c in enumerate(CATEGORIES, start=1):
        print("{}. {}".format(i, c))
    print("---------------------------\n")

def category_handler():
    # Handler of the category sub-menu
    category_operations()
    operation_id = common.get_menu_id("Choose operation")
    if common.check_menu_id(operation_id, CATEGORY_OPERATIONS):
        if operation_id == 1:
            add_category()
        elif operation_id == 2:
            list_categories()
